/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package data;

/**
 *
 * @author tiago
 */

import java.sql.PreparedStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Date;


public class FilmeDao {
    
    Connection conn;
    PreparedStatement st;
    ResultSet rs;
    
    public boolean conectar(){
    
        try{
        
            Class.forName("com.mysql.cj.jdbc.Driver");
            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/cenaflix","root", "tiago");
            System.out.println("Conexão com o banco efetuada com exito!!!");
            return true;
        }catch(ClassNotFoundException | SQLException ex){
        
            System.out.println("Erro ao conectar: " + ex.getMessage());
            return false;
        }
        
    }
    
    public String formatarData(String data) throws Exception {
        SimpleDateFormat formatoEntrada = new SimpleDateFormat("dd/MM/yyyy");
        SimpleDateFormat formatoSaida = new SimpleDateFormat("yyyy-MM-dd");
        Date dataFormatada = formatoEntrada.parse(data);
        return formatoSaida.format(dataFormatada);}
    
    public int salvar(Filme filme) {
    int status;
    try {
        // Formatar a data para o formato esperado pelo banco (yyyy-MM-dd)
        String dataFormatada = formatarData(filme.getData());

        // Preparar a consulta SQL
        st = conn.prepareStatement("INSERT INTO filmes (nome, datalancamento, categoria) VALUES (?, ?, ?)");
        st.setString(1, filme.getNome());
        st.setString(2, dataFormatada);  // Usar a data formatada
        st.setString(3, filme.getCategoria());

        // Executar a atualização e retornar o status
        status = st.executeUpdate();
        return status; // Retornar 1 para indicar sucesso
    } catch (SQLException ex) {
        System.out.println("Erro ao conectar: " + ex.getMessage());
        return ex.getErrorCode(); // Retorna o código de erro do SQL
    } catch (Exception ex) {
        // Tratar possíveis erros de formatação de data
        System.out.println("Erro ao formatar data: " + ex.getMessage());
        return -1; // Indica erro na formatação da data
    }
}


    public void desconectar(){
    
        try{
        
            conn.close();
        }catch(SQLException ex){
        
            //pode-se deixar vazio para evitar uma mensagem de erro desnecessária ao usuário
        }
        
        
    }
}
